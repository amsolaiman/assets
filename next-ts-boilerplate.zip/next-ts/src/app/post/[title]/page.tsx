// sections
import { PostDetailsHomeView } from 'src/sections/blog/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Post: Details',
};

export default function PostDetailsHomePage() {
  return <PostDetailsHomeView />;
}
