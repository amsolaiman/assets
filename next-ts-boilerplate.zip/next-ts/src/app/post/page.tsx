// sections
import { PostListHomeView } from 'src/sections/blog/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Post: List',
};

export default function PostListHomePage() {
  return <PostListHomeView />;
}
