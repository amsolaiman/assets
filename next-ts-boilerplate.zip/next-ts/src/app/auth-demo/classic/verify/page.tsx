// sections
import { ClassicVerifyView } from 'src/sections/auth-demo/classic';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Classic: Verify',
};

export default function ClassicVerifyPage() {
  return <ClassicVerifyView />;
}
