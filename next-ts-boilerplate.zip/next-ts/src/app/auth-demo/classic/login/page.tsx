// sections
import { ClassicLoginView } from 'src/sections/auth-demo/classic';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Classic: Login',
};

export default function ClassicLoginPage() {
  return <ClassicLoginView />;
}
