// sections
import { ClassicRegisterView } from 'src/sections/auth-demo/classic';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Classic: Register',
};

export default function ClassicRegisterPage() {
  return <ClassicRegisterView />;
}
