// sections
import { ModernVerifyView } from 'src/sections/auth-demo/modern';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Modern: Verify',
};

export default function ModernVerifyPage() {
  return <ModernVerifyView />;
}
