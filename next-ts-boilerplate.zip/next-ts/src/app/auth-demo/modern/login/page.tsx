// sections
import { ModernLoginView } from 'src/sections/auth-demo/modern';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Auth Modern: Login',
};

export default function ModernLoginPage() {
  return <ModernLoginView />;
}
