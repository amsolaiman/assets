// sections
import { AmplifyRegisterView } from 'src/sections/auth/amplify';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Amplify: Register',
};

export default function RegisterPage() {
  return <AmplifyRegisterView />;
}
