// sections
import { AmplifyVerifyView } from 'src/sections/auth/amplify';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Amplify: Verify',
};

export default function VerifyPage() {
  return <AmplifyVerifyView />;
}
