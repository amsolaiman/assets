// sections
import MarkdownView from 'src/sections/_examples/extra/markdown-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Markdown',
};

export default function MarkdownPage() {
  return <MarkdownView />;
}
