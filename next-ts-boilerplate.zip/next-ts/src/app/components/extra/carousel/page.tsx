// sections
import CarouselView from 'src/sections/_examples/extra/carousel-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Carousel',
};

export default function CarouselPage() {
  return <CarouselView />;
}
