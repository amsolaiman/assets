// sections
import EditorView from 'src/sections/_examples/extra/editor-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Editor',
};

export default function EditorPage() {
  return <EditorView />;
}
