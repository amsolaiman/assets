// sections
import ImageView from 'src/sections/_examples/extra/image-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Image',
};

export default function ImagePage() {
  return <ImageView />;
}
