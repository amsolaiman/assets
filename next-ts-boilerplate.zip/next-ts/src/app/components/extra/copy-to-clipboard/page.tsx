// sections
import CopyToClipboardView from 'src/sections/_examples/extra/copy-to-clipboard-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Copy to Clipboard',
};

export default function CopyToClipboardPage() {
  return <CopyToClipboardView />;
}
