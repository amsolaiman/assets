// sections
import SnackbarView from 'src/sections/_examples/extra/snackbar-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Snackbar',
};

export default function SnackbarPage() {
  return <SnackbarView />;
}
