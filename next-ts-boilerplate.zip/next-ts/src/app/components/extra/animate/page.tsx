// sections
import AnimateView from 'src/sections/_examples/extra/animate-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Animate',
};

export default function AnimatePage() {
  return <AnimateView />;
}
