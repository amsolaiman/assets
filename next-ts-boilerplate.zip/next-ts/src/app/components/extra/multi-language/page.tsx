// sections
import MultiLanguageView from 'src/sections/_examples/extra/multi-language-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Multi Language',
};

export default function MultiLanguagePage() {
  return <MultiLanguageView />;
}
