// sections
import ScrollView from 'src/sections/_examples/extra/scroll-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Scroll',
};

export default function ScrollPage() {
  return <ScrollView />;
}
