// sections
import OrganizationalChartView from 'src/sections/_examples/extra/organizational-chart-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Organizational Chart',
};

export default function OrganizationalChartPage() {
  return <OrganizationalChartView />;
}
