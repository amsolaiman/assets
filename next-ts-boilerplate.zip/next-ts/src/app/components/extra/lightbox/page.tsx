// sections
import LightboxView from 'src/sections/_examples/extra/lightbox-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Lightbox',
};

export default function LightboxPage() {
  return <LightboxView />;
}
