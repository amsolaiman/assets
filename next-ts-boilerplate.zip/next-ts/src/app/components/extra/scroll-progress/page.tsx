// sections
import ScrollProgressView from 'src/sections/_examples/extra/scroll-progress-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Scroll Progress',
};

export default function ScrollProgressPage() {
  return <ScrollProgressView />;
}
