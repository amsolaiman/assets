// sections
import TextMaxLineView from 'src/sections/_examples/extra/text-max-line-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Text Max Line',
};

export default function TextMaxLinePage() {
  return <TextMaxLineView />;
}
