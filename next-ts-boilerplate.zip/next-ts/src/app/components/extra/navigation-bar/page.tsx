// sections
import NavigationBarView from 'src/sections/_examples/extra/navigation-bar-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Navigation Bar',
};

export default function NavigationBarPage() {
  return <NavigationBarView />;
}
