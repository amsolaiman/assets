// sections
import MegaMenuView from 'src/sections/_examples/extra/mega-menu-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Mega Menu',
};

export default function MegaMenuPage() {
  return <MegaMenuView />;
}
