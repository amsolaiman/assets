// sections
import ChartView from 'src/sections/_examples/extra/chart-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Extra: Chart',
};

export default function ChartPage() {
  return <ChartView />;
}
