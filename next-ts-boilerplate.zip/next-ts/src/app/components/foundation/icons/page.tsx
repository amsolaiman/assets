// sections
import { IconsView } from 'src/sections/_examples/foundation';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Foundations: Icons',
};

export default function IconsPage() {
  return <IconsView />;
}
