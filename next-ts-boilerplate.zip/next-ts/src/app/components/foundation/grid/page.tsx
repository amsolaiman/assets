// sections
import { GridView } from 'src/sections/_examples/foundation';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Foundations: Grid',
};

export default function GridPage() {
  return <GridView />;
}
