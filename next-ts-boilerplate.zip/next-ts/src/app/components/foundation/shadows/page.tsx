// sections
import { ShadowsView } from 'src/sections/_examples/foundation';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Foundations: Shadows',
};

export default function ShadowsPage() {
  return <ShadowsView />;
}
