// sections
import PopoverView from 'src/sections/_examples/mui/popover-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Popover',
};

export default function PopoverPage() {
  return <PopoverView />;
}
