// sections
import AccordionView from 'src/sections/_examples/mui/accordion-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Accordion',
};

export default function AccordionPage() {
  return <AccordionView />;
}
