// sections
import CheckboxView from 'src/sections/_examples/mui/checkbox-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Checkbox',
};

export default function CheckboxPage() {
  return <CheckboxView />;
}
