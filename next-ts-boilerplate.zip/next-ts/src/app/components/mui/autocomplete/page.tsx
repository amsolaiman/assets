// sections
import AutocompleteView from 'src/sections/_examples/mui/autocomplete-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Autocomplete',
};

export default function AutocompletePage() {
  return <AutocompleteView />;
}
