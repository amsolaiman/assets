// sections
import ChipView from 'src/sections/_examples/mui/chip-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Chip',
};

export default function ChipPage() {
  return <ChipView />;
}
