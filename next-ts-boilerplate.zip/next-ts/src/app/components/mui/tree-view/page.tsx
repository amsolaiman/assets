// sections
import TreeViews from 'src/sections/_examples/mui/tree-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: TreeView',
};

export default function TreeViewPage() {
  return <TreeViews />;
}
