// sections
import TableView from 'src/sections/_examples/mui/table-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Table',
};

export default function TablePage() {
  return <TableView />;
}
