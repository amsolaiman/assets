// sections
import BreadcrumbsView from 'src/sections/_examples/mui/breadcrumbs-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Breadcrumbs',
};

export default function BreadcrumbsPage() {
  return <BreadcrumbsView />;
}
