// sections
import DialogView from 'src/sections/_examples/mui/dialog-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Dialog',
};

export default function DialogPage() {
  return <DialogView />;
}
