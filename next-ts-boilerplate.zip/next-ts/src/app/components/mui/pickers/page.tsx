// sections
import PickerView from 'src/sections/_examples/mui/picker-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Picker',
};

export default function PickerPage() {
  return <PickerView />;
}
