// sections
import TimelineView from 'src/sections/_examples/mui/timeline-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Timeline',
};

export default function TimelinePage() {
  return <TimelineView />;
}
