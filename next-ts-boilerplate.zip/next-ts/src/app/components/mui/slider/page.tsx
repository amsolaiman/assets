// sections
import SliderView from 'src/sections/_examples/mui/slider-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Slider',
};

export default function SliderPage() {
  return <SliderView />;
}
