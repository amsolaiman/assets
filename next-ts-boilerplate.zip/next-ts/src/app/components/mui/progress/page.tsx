// sections
import ProgressView from 'src/sections/_examples/mui/progress-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Progress',
};

export default function ProgressPage() {
  return <ProgressView />;
}
