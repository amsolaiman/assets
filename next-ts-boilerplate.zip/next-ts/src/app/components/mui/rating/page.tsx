// sections
import RatingView from 'src/sections/_examples/mui/rating-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Rating',
};

export default function RatingPage() {
  return <RatingView />;
}
