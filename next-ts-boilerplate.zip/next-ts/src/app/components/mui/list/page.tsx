// sections
import ListView from 'src/sections/_examples/mui/list-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: List',
};

export default function ListPage() {
  return <ListView />;
}
