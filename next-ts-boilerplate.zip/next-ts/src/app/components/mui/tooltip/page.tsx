// sections
import TooltipView from 'src/sections/_examples/mui/tooltip-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'MUI: Tooltip',
};

export default function TooltipPage() {
  return <TooltipView />;
}
