// sections
import { ContactView } from 'src/sections/contact/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Contact us',
};

export default function ContactPage() {
  return <ContactView />;
}
