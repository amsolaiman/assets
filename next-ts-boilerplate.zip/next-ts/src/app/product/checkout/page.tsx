// sections
import { CheckoutView } from 'src/sections/product/checkout/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Checkout',
};

export default function CheckoutPage() {
  return <CheckoutView />;
}
