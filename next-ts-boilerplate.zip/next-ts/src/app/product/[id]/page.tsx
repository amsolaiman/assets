// sections
import { ProductShopDetailsView } from 'src/sections/product/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Product: Details',
};

export default function ProductShopDetailsPage() {
  return <ProductShopDetailsView />;
}
