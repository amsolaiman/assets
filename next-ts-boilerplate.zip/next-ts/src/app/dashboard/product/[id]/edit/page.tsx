// sections
import { ProductEditView } from 'src/sections/product/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Product Edit',
};

export default function ProductEditPage() {
  return <ProductEditView />;
}
