// sections
import { JobEditView } from 'src/sections/job/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Job Edit',
};

export default function JobEditPage() {
  return <JobEditView />;
}
