// sections
import { JobDetailsView } from 'src/sections/job/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Job Details',
};

export default function JobDetailsPage() {
  return <JobDetailsView />;
}
