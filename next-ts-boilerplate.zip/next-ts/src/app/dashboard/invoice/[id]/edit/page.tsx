// sections
import { InvoiceEditView } from 'src/sections/invoice/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Invoice Edit',
};

export default function InvoiceEditPage() {
  return <InvoiceEditView />;
}
