// sections
import { OverviewEcommerceView } from 'src/sections/overview/e-commerce/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: E-Commerce',
};

export default function OverviewEcommercePage() {
  return <OverviewEcommerceView />;
}
