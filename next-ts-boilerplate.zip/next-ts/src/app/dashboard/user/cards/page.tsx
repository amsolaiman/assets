// sections
import { UserCardsView } from 'src/sections/user/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: User Cards',
};

export default function UserCardsPage() {
  return <UserCardsView />;
}
