// sections
import { TourDetailsView } from 'src/sections/tour/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Tour Details',
};

export default function TourDetailsPage() {
  return <TourDetailsView />;
}
