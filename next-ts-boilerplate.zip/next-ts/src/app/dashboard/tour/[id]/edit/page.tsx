// sections
import { TourEditView } from 'src/sections/tour/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Tour Edit',
};

export default function TourEditPage() {
  return <TourEditView />;
}
