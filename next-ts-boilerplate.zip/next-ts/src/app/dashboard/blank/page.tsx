// sections
import BlankView from 'src/sections/blank/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: Blank',
};

export default function BlankPage() {
  return <BlankView />;
}
